<script>
// export default {
//   name: 'welcome',
// }
// </script>

<template>
  <div>
    <h1>欢迎来到主页面</h1>
    <router-link to="/login">去登录</router-link>
  </div>
</template>

<style scoped></style>
