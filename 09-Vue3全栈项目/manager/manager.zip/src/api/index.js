import request from "../utils/request"
export default {
  login(param) {
    return request({
      url: '/users/login',
      method: 'post',
      data: param,
      // mock: true, // 是否使用mock
    })
  }
}