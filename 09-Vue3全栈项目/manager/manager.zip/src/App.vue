<script>
export default {
  name: 'app',
}
</script>

<template>
  <router-view></router-view>
</template>

<style lang="scss">
@import './assets/style/index.scss'; 
@import './assets/style/reset.css';
</style>
