// 关闭eslint, 反向代理等
module.exports = {
  lintOnSave: false
}
