<template>
  <div>商品管理页面</div>
</template>
